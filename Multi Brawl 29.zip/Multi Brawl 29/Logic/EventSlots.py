import time

class EventSlots:
    maps = [
        {
            'ID': 309, # Big Game
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },

        {
            'ID': 309, # Showdown
            'Status': 3,
            'Ended': False,
            'Modifier': 4,
            'Timer': 86400,
        },

        {
            'ID': 309, # Heist
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },

        {
            'ID': 309, # Bounty
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },

        {
            'ID': 309, # Brawl Ball
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },

        {
            'ID': 269, # Rampage
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },
        {
            'ID': 309, # Hot Zone
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },
        {
            'ID': 309, # Rampage
            'Status': 3,
            'Ended': False,
            'Modifier': 0,
            'Timer': 86400,
        },


    ]